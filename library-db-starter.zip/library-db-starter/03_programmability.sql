/*
03_programmability.sql — 檢視(Views)與預存程序(Stored Procedures)
*/
USE LibraryDB;
GO

-- 目前未歸還的借閱清單
IF OBJECT_ID('dbo.v_CurrentLoans', 'V') IS NOT NULL DROP VIEW dbo.v_CurrentLoans;
GO
CREATE VIEW dbo.v_CurrentLoans AS
SELECT
    l.LoanId,
    m.FullName AS MemberName,
    b.Title,
    c.Barcode,
    l.LoanDate,
    l.DueDate,
    DATEDIFF(day, CAST(GETDATE() AS DATE), l.DueDate) AS DaysLeft
FROM dbo.Loan l
JOIN dbo.Member m   ON l.MemberId = m.MemberId
JOIN dbo.BookCopy c ON l.CopyId   = c.CopyId
JOIN dbo.Book b     ON c.BookId   = b.BookId
WHERE l.ReturnDate IS NULL;
GO

-- 借書：輸入條碼、會員、借期天數（預設14天）
IF OBJECT_ID('dbo.usp_BorrowBook', 'P') IS NOT NULL DROP PROCEDURE dbo.usp_BorrowBook;
GO
CREATE PROCEDURE dbo.usp_BorrowBook
    @Barcode   NVARCHAR(50),
    @MemberId  INT,
    @LoanDays  INT = 14
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CopyId INT = (SELECT CopyId FROM dbo.BookCopy WHERE Barcode = @Barcode);
    IF @CopyId IS NULL
    BEGIN
        RAISERROR(N'找不到此條碼的副本。', 16, 1);
        RETURN;
    END

    -- 檢查是否已有未歸還的借閱
    IF EXISTS (SELECT 1 FROM dbo.Loan WHERE CopyId = @CopyId AND ReturnDate IS NULL)
    BEGIN
        RAISERROR(N'此副本目前已外借中。', 16, 1);
        RETURN;
    END

    DECLARE @LoanDate DATE = CAST(GETDATE() AS DATE);
    DECLARE @DueDate  DATE = DATEADD(day, @LoanDays, @LoanDate);

    INSERT INTO dbo.Loan(CopyId, MemberId, LoanDate, DueDate)
    VALUES(@CopyId, @MemberId, @LoanDate, @DueDate);

    UPDATE dbo.BookCopy SET Status = N'Loaned' WHERE CopyId = @CopyId;
END
GO

-- 還書：輸入 LoanId（或可擴充成條碼+會員）
IF OBJECT_ID('dbo.usp_ReturnBook', 'P') IS NOT NULL DROP PROCEDURE dbo.usp_ReturnBook;
GO
CREATE PROCEDURE dbo.usp_ReturnBook
    @LoanId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CopyId INT = (SELECT CopyId FROM dbo.Loan WHERE LoanId = @LoanId);
    IF @CopyId IS NULL
    BEGIN
        RAISERROR(N'找不到此借閱編號。', 16, 1);
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM dbo.Loan WHERE LoanId = @LoanId AND ReturnDate IS NOT NULL)
    BEGIN
        RAISERROR(N'此借閱已完成還書。', 16, 1);
        RETURN;
    END

    UPDATE dbo.Loan
    SET ReturnDate = CAST(GETDATE() AS DATE)
    WHERE LoanId = @LoanId;

    UPDATE dbo.BookCopy SET Status = N'Available' WHERE CopyId = @CopyId;
END
GO