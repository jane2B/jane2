/*
01_schema.sql — 建立資料庫與資料表（SQL Server）
執行步驟：
1) 在 SSMS 新增查詢視窗。
2) 逐段執行（先 CREATE DATABASE，再 USE，最後 CREATE TABLE/INDEX）。
*/
IF DB_ID(N'LibraryDB') IS NULL
BEGIN
    CREATE DATABASE LibraryDB;
END
GO

USE LibraryDB;
GO

-- 清除舊表（如果重複執行用）
IF OBJECT_ID('dbo.Loan', 'U') IS NOT NULL DROP TABLE dbo.Loan;
IF OBJECT_ID('dbo.BookCopy', 'U') IS NOT NULL DROP TABLE dbo.BookCopy;
IF OBJECT_ID('dbo.BookAuthor', 'U') IS NOT NULL DROP TABLE dbo.BookAuthor;
IF OBJECT_ID('dbo.Book', 'U') IS NOT NULL DROP TABLE dbo.Book;
IF OBJECT_ID('dbo.Author', 'U') IS NOT NULL DROP TABLE dbo.Author;
IF OBJECT_ID('dbo.Member', 'U') IS NOT NULL DROP TABLE dbo.Member;
GO

-- 會員
CREATE TABLE dbo.Member
(
    MemberId     INT IDENTITY(1,1) PRIMARY KEY,
    FullName     NVARCHAR(100) NOT NULL,
    Email        NVARCHAR(255) NULL UNIQUE,
    Phone        NVARCHAR(30)  NULL,
    IsActive     BIT NOT NULL CONSTRAINT DF_Member_IsActive DEFAULT(1),
    CreatedAt    DATETIME2(0) NOT NULL CONSTRAINT DF_Member_CreatedAt DEFAULT SYSUTCDATETIME()
);
GO

-- 作者
CREATE TABLE dbo.Author
(
    AuthorId INT IDENTITY(1,1) PRIMARY KEY,
    Name     NVARCHAR(100) NOT NULL,
    Bio      NVARCHAR(4000) NULL
);
GO

-- 書籍（書目，不含實體副本）
CREATE TABLE dbo.Book
(
    BookId         INT IDENTITY(1,1) PRIMARY KEY,
    Title          NVARCHAR(200) NOT NULL,
    Isbn13         CHAR(13)      NOT NULL,
    PublishedYear  INT           NULL,
    Category       NVARCHAR(50)  NULL,
    CONSTRAINT UQ_Book_ISBN UNIQUE (Isbn13),
    CONSTRAINT CK_Book_Year CHECK (PublishedYear IS NULL OR (PublishedYear BETWEEN 1500 AND YEAR(GETDATE())+1))
);
GO

-- 多對多：書籍-作者
CREATE TABLE dbo.BookAuthor
(
    BookId   INT NOT NULL,
    AuthorId INT NOT NULL,
    CONSTRAINT PK_BookAuthor PRIMARY KEY (BookId, AuthorId),
    CONSTRAINT FK_BookAuthor_Book   FOREIGN KEY (BookId)   REFERENCES dbo.Book(BookId)   ON DELETE CASCADE,
    CONSTRAINT FK_BookAuthor_Author FOREIGN KEY (AuthorId) REFERENCES dbo.Author(AuthorId) ON DELETE CASCADE
);
GO

-- 書籍實體副本
CREATE TABLE dbo.BookCopy
(
    CopyId   INT IDENTITY(1,1) PRIMARY KEY,
    BookId   INT NOT NULL,
    Barcode  NVARCHAR(50) NOT NULL UNIQUE,
    Status   NVARCHAR(20) NOT NULL CONSTRAINT DF_BookCopy_Status DEFAULT(N'Available')  -- Available, Loaned, Lost, Damaged
    CONSTRAINT FK_BookCopy_Book FOREIGN KEY (BookId) REFERENCES dbo.Book(BookId) ON DELETE CASCADE
);
GO

-- 借閱紀錄
CREATE TABLE dbo.Loan
(
    LoanId     INT IDENTITY(1,1) PRIMARY KEY,
    CopyId     INT NOT NULL,
    MemberId   INT NOT NULL,
    LoanDate   DATE NOT NULL CONSTRAINT DF_Loan_LoanDate DEFAULT (CAST(GETDATE() AS DATE)),
    DueDate    DATE NOT NULL,
    ReturnDate DATE NULL,
    CONSTRAINT FK_Loan_Copy   FOREIGN KEY (CopyId)   REFERENCES dbo.BookCopy(CopyId),
    CONSTRAINT FK_Loan_Member FOREIGN KEY (MemberId) REFERENCES dbo.Member(MemberId),
    CONSTRAINT CK_Loan_Dates CHECK (DueDate >= LoanDate AND (ReturnDate IS NULL OR ReturnDate >= LoanDate))
);
GO

-- 防止同一副本同時有多筆「未歸還」的借閱（Filtered Unique Index）
CREATE UNIQUE INDEX UX_Loan_Copy_Active
ON dbo.Loan(CopyId)
WHERE ReturnDate IS NULL;
GO

-- 常用索引
CREATE INDEX IX_Book_Title ON dbo.Book(Title);
CREATE INDEX IX_Book_Category ON dbo.Book(Category);
CREATE INDEX IX_BookCopy_BookId ON dbo.BookCopy(BookId);
CREATE INDEX IX_Loan_Member ON dbo.Loan(MemberId);
CREATE INDEX IX_Loan_DueDate ON dbo.Loan(DueDate);
GO