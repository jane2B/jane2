# 簡易圖書借閱管理系統 — 作業交付包

這個資料夾提供你快速完成作業所需的 **SQL 腳本** 與 **步驟說明**。請依照 `一步一步流程（速查版）` 執行。

## 檔案說明
- `01_schema.sql`：建立資料庫與所有資料表、索引、約束。
- `02_seed.sql`：插入測試資料（會員 / 書籍 / 作者 / 副本 / 借閱）。
- `03_programmability.sql`：常用檢視與預存程序（借書 / 還書）。

---

## 一步一步流程（速查版）

### A. 建立資料庫與資料表（SSMS）
1. 開啟 **SQL Server Management Studio** → 連線到本機或學校的 SQL Server。
2. 開啟新查詢視窗，執行 `01_schema.sql`（可分段執行）。
3. 執行完成後，展開資料庫 `LibraryDB` → Tables，確認 6 張表已建立：
   - Member / Author / Book / BookAuthor / BookCopy / Loan

### B. 匯入測試資料
1. 於同一個資料庫 `LibraryDB`，執行 `02_seed.sql`。
2. 可以用下列查詢看看結果：
   ```sql
   SELECT * FROM dbo.Member;
   SELECT TOP 10 * FROM dbo.v_CurrentLoans;
   ```

### C. 建立 ER 圖（Database Diagram）
1. 在 `LibraryDB` 下，右鍵 **Database Diagrams** → `Install Diagram Support`（若出現提示就同意）。
2. 右鍵 **Database Diagrams** → `New Database Diagram`。
3. 將 6 張表全選加入，按 `Arrange` 自動排版，拖曳調整關聯線，按儲存（取名 `LMS_ERD`）。
4. 請截圖包含主鍵/外鍵與關聯線的視圖。

### D. 建立程式物件（View/Stored Procedure）
1. 執行 `03_programmability.sql`。
2. 測試：
   - 借書：`EXEC dbo.usp_BorrowBook @Barcode = N'NW-0001', @MemberId = 1, @LoanDays = 14;`
   - 還書：先查 `SELECT * FROM dbo.v_CurrentLoans;` 找到 LoanId → `EXEC dbo.usp_ReturnBook @LoanId = 1;`

### E. 快速做一個可截圖的介面（ASP.NET Core MVC，選一條路徑即可）

**路徑 1：Visual Studio（GUI）**
1. 建立新專案：`ASP.NET Core Web App (Model-View-Controller)`。
2. 目標 Framework 選 `.NET 8`（或學校指定版本）。
3. 以 NuGet 安裝：`Microsoft.EntityFrameworkCore.SqlServer`、`Microsoft.EntityFrameworkCore.Tools`。
4. **反向工程資料庫**：
   - 工具 → NuGet 封裝管理員 → 封裝管理員主控台（PMC）。
   - 執行：
     ```powershell
     Scaffold-DbContext "Server=.\SQLEXPRESS;Database=LibraryDB;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Context LibraryContext -DataAnnotations
     ```
5. 在 *Controllers* 目錄新增 **MVC Controller with views, using EF**，為下列實體各建一組 CRUD：
   - Book、Author、Member、BookCopy、Loan。
6. 執行（F5）。截圖 3–5 個重點功能頁面：
   - 書籍清單（含搜尋框）
   - 會員清單
   - 借閱紀錄（Index）
   - 新增借閱（Create）或還書（Edit/自訂按鈕）
   - 目前未歸還清單（用 `v_CurrentLoans` 做成頁面或直接在 Loan Index 加上篩選）

**路徑 2：.NET CLI（命令列）**
```bash
dotnet new mvc -n LibraryWeb
cd LibraryWeb
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet tool install --global dotnet-ef
dotnet ef dbcontext scaffold "Server=.\SQLEXPRESS;Database=LibraryDB;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -o Models -c LibraryContext --data-annotations
# 接著用任何編輯器新增 CRUD 控制器與視圖（或使用 VS Code 擴充套件產生器）
dotnet run
```

> **借/還書按鈕做法（簡易）**：在 Loan Index 頁面新增「還書」按鈕，連到一個 Action 執行 `EXEC dbo.usp_ReturnBook @LoanId`；新增借書頁面可輸入條碼與會員，呼叫 `usp_BorrowBook`。

### F. 實機展示建議
- Demo 流程（約 2–3 分鐘）：
  1. 展示 ER 圖 → 解釋表與關聯。
  2. 開啟網站：先看書籍清單、會員清單。
  3. 操作「借書」→ 立刻在「目前未歸還」看到新紀錄。
  4. 操作「還書」→ 狀態從 Loaned 變回 Available。

### G. 上傳 GitHub（Public）
```bash
# 在專案根目錄
git init
echo "bin/" >> .gitignore
echo "obj/" >> .gitignore
echo ".vs/" >> .gitignore
git add .
git commit -m "LibraryDB starter: schema + seed + EF MVC scaffolding steps"
git branch -M main
git remote add origin https://github.com/<你的帳號>/LibraryDB-Homework.git
git push -u origin main
# 到 GitHub 專案 Settings → General → 修改 Visibility 為 Public（若尚未公開）。
```

---

## 交付清單對照
1. **系統名稱**：簡易圖書借閱管理系統（可自行命名）。  
2. **資料庫 Diagram**：SSMS → Database Diagrams → `LMS_ERD`。  
3. **CREATE TABLE 語法**：`01_schema.sql`。  
4. **系統功能介面截圖**：ASP.NET MVC 產生之 CRUD 頁面 + 借/還書操作。  
5. **實機展示**：依 Demo 流程操作。  
6. **GitHub 連結**：上傳專案與 SQL 腳本，設為 public。

---

> 小提醒：若學校用 Azure Data Studio，也能執行同樣的 SQL。Database Diagram 功能以 SSMS 最方便。